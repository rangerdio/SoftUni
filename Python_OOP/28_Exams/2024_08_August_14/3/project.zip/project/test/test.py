from project.furniture import Furniture

