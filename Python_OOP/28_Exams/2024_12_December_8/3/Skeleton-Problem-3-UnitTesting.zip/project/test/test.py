from project.senior_student import SeniorStudent

