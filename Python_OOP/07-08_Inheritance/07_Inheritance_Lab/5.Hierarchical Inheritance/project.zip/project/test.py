from project.dog import Dog
from project.cat import Cat

cat = Cat()
dog = Dog()
print(cat.eat())
print(cat.meow())
print(dog.eat())
print(dog.bark())
