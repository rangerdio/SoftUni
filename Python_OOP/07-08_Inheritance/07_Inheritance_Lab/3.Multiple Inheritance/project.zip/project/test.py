from project.teacher import Teacher

koko = Teacher()
print(koko.teach())
print(koko.sleep())
print(koko.get_fired())
