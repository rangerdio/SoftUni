from project.sports_car import SportsCar

koko = SportsCar()
print(koko.race())
print(koko.drive())
print(koko.move())
