from project.food.food import Food


class Starter(Food):
    pass
